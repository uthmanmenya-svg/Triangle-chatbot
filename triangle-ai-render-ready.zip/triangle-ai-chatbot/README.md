# TRIANGLE AI — Triangle Senior Secondary School Chatbot

A standalone browser-based chatbot for Triangle Senior Secondary School. It answers questions about the school using the supplied brochure information and helps with academic subjects at O-Level and A-Level.

## Requirements

- Node.js 22 or newer
- An OpenAI API key configured by the school administrator
- Internet access while using the AI service

## Setup (Windows)

1. Install Node.js 22 LTS or newer.
2. Extract this folder to a location such as `C:\TriangleAI`.
3. Open Command Prompt in the extracted `triangle-ai-chatbot` folder.
4. Run:

   ```bat
   npm install
   ```

5. Make a copy of `.env.example` and name the copy `.env`.
6. Open `.env` in Notepad and replace the placeholder with the school's private API key. Keep this key on the server only. Never paste it into `public/index.html`, send it to students, or commit it to a public repository.
7. Start the application:

   ```bat
   npm start
   ```

8. Open `http://localhost:3000` in a browser on that computer.

To allow other devices on the same school network to access it, the administrator can run the server on a school computer and open `http://SERVER-COMPUTER-IP:3000` from another device, subject to the school's firewall/network settings. For access from outside the school network, deploy it to a secure hosting provider and enable HTTPS.

## Configuration

- `OPENAI_API_KEY`: private API key used by the server.
- `OPENAI_MODEL`: model available to the school's API project. Default: `gpt-4.1-mini`. Set this to a model available to your API project.
- `PORT`: local server port. Default: `3000`.

## Updating school information

Edit `knowledge.js`, save the file, and restart the server. The current knowledge was transcribed from the two supplied school brochures. Verify all school-specific details with the administration before public launch, especially:

- the email address (the print in the brochure is not perfectly clear);
- telephone numbers and current staff titles;
- current fees and the period they cover;
- current admission status;
- bank and mobile-money payment instructions.

The chatbot intentionally does not reproduce bank account numbers or payment codes. It directs families to the school office for verified payment details.

## Scope and privacy

The server instructions restrict answers to Triangle Senior Secondary School information and academic learning. It rejects unrelated questions. This is an AI instruction-based restriction, not a perfect content-security guarantee; test it before launch and supervise public deployment. The server sends recent chat messages to the AI provider to maintain conversational context. The app does not save chats to a school database. The API key stays on the server and is not sent to the browser. Use HTTPS when deployed publicly.

## Project files

- `server.js` — Express server and AI API connection
- `knowledge.js` — school information from the brochures
- `public/index.html` — standalone chatbot interface
- `.env.example` — configuration template


## Deploy free on Render

1. Create a GitHub account and a new **public or private repository** named `triangle-ai-chatbot`.
2. Upload the contents of this project folder to the repository (the `package.json`, `server.js`, `knowledge.js`, `render.yaml`, and `public` folder must be at the repository root).
3. Sign in at https://render.com/ and choose **New → Web Service**. Connect the GitHub repository.
4. Render should detect `render.yaml`. If configuring manually, use:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
   - Instance type: Free
5. In the Render service's **Environment** settings, add `OPENAI_API_KEY` with the school's private API key. Optionally add `OPENAI_MODEL` with `gpt-4.1-mini`. Do not put the key in GitHub or in browser code.
6. Deploy. Render will provide a public `https://...onrender.com` address. Open it and test `/api/health` and the chat.

### Free-plan limitations and costs

Render's free web services can spin down after inactivity and may take time to wake up. Free hosting does not include OpenAI API usage: AI responses can incur separate API charges. Set an API spending limit and monitor usage in the OpenAI Platform before sharing the link widely.
