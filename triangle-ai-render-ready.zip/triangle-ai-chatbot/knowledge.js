// School facts transcribed from the two Triangle Senior Secondary School brochures.
// Review and update this file with the school administration before public launch.
export const SCHOOL_KNOWLEDGE = `
TRIANGLE SENIOR SECONDARY SCHOOL — SCHOOL KNOWLEDGE BASE

IDENTITY AND LOCATION
- Official name shown in the brochure: Triangle Senior Secondary School (also written Triangle SS / Triangle SSS).
- Type: Mixed day and boarding secondary school.
- Levels: O-Level and A-Level; Arts and Sciences are offered at A-Level.
- UNEB centre number: U1530.
- Address/location: Buliigo Ward, Iganga Municipality, Iganga, Uganda.
- Postal address shown in the brochure: P.O. Box 328, Iganga (U).
- Motto: “Discipline With A Vision”.
- Website printed in the brochure: www.trianglesecondaryschool.com.
- Email printed in the brochure appears as trianglessonchool3@gmail.com; spelling should be verified by the school office before publication.
- Telephone numbers printed in the brochures: 0751 648932, 0784 351565, 0752 814887. Formatting may vary; confirm before relying on them.

HISTORY AND ADMINISTRATION
- The brochure says the school was founded in 2000 by Mr. Okello Richard, identified there as Director, with a handful of students, more than seven teachers and one classroom block.
- The brochure identifies Mr. Okello Richard as Headteacher in the administration photograph caption. The school should confirm his current title before public use.
- The brochure says the school obtained UNEB centre number U1530 for O-Level in 2004.
- The brochure says A-Level began in 2022 and that its best candidate that year scored 15 points.
- The brochure describes the school as continuing to maintain its performance among schools in Iganga and Uganda. Treat this as brochure wording, not an independently verified ranking.

VISION
“To develop well-rounded, confident and responsible individuals who inspire to achieve their full potential.”

MISSION
“To create and maintain an effective learning environment by establishing behavioural support and the social culture needed for all students in our school to achieve social and academic success.”

CORE VALUES
Integrity; God-fearing; self-esteem; self-respect; discipline with a vision.

WHAT MAKES THE SCHOOL UNIQUE (BROCHURE)
Academic excellence; discipline and integrity; talent development; supportive learning environment; experienced teachers.

CO-CURRICULAR ACTIVITIES
The brochure mentions MDD (Music, Dance and Drama), football, netball, chess and volleyball.

FACILITIES DESCRIBED IN THE BROCHURE
- Modern library with textbooks, dictionaries and encyclopedias.
- Science laboratory for practical learning in Biology, Chemistry and Physics.
- Modern computer laboratory with computers and mini-computers/tablets; the brochure says internet was installed.
- Classroom block, shown in an aerial photograph.

FEES SHOWN IN THE BROCHURE
- S1–S4 day: UGX 260,000 (the brochure does not clearly state the term/period).
- S5–S6 day: UGX 300,000 (the brochure does not clearly state the term/period).
- Boarding: UGX 600,000 (the brochure does not clearly state which classes or the term/period).
IMPORTANT: These are figures printed in the supplied brochure and may be outdated or incomplete. Always advise families to confirm the current fee structure, inclusions and payment details directly with the school office before making any payment.

PAYMENT INFORMATION
The brochure mentions bank payment through Equity Bank, Iganga Branch, and Opportunity Bank, Iganga Branch, as well as MTN Mobile Money and Airtel Money. Account details and USSD instructions are intentionally not reproduced in this public chatbot knowledge base. Direct families to the school office for verified payment instructions. Never invent or guess account numbers, payment codes or payment recipients.

ADMISSIONS
The brochure states “Admission in Progress” and “Join us Today”. This may no longer be current. If asked whether admission is open now, explain that the brochure showed admission in progress when it was prepared, but current availability must be confirmed with the school office.

IMPORTANT LIMITS ON SCHOOL FACTS
- The brochures are the only source for school-specific facts in this knowledge base.
- Do not invent admission deadlines, scholarships, boarding rules, subject combinations, staff names, current fees, exam results, school rankings, transport routes or opening dates.
- If a fact is missing, say it is not stated in the brochure and recommend confirming it with the school office.
- Clearly identify brochure figures as brochure figures, not guaranteed current information.
`;
